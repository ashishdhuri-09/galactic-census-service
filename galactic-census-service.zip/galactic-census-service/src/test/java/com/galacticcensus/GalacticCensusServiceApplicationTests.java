package com.galacticcensus;

import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.galacticcensus.entity.Person;
import com.galacticcensus.model.PersonVO;
import com.galacticcensus.service.PersonService;
import com.galacticcensus.util.DateUtil;

@SpringBootTest
class GalacticCensusServiceApplicationTests {

	@MockBean
	private List<Person> censusData;

	@MockBean
	private DateUtil dateUtil;

	@Autowired
	private PersonService personService;

	@Test
	void contextLoads() {
	}

	@Test
	void testAddPersonSuccess() {
		PersonVO personVO = new PersonVO();
		personVO.setFullName("John Doe");
		personVO.setDateOfBirth("10/10/2023");
		personVO.setPlanetOfResidence("Mars");
		personVO.setGender("MALE");
		personVO.setLocalAddress("Mars, Red Street");
		personVO.setAnnualIncome("50000");

		when(censusData.size()).thenReturn(1);

		Assertions.assertEquals("1 Person added successfully", personService.addPerson(personVO).getMessage());
	}

	@Test
	void testAddPersonFailure() {
		PersonVO personVO = new PersonVO();
		personVO.setFullName("");
		personVO.setDateOfBirth("10/15/2023");
		personVO.setPlanetOfResidence("");
		personVO.setGender("TRANSGENDER");
		personVO.setLocalAddress("Mars, Red Street");
		personVO.setAnnualIncome("hundred");

		when(censusData.size()).thenReturn(1);

		Assertions.assertEquals("Failed to add person", personService.addPerson(personVO).getErrorMessage());
	}

}
