package com.galacticcensus.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.List;
import org.springframework.http.HttpStatus;

@JsonInclude(value = Include.NON_EMPTY)
public class CommonException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  private List<String> validationError;
  private final String errorMessage;
  private final HttpStatus statusCode;

  public List<String> getValidationError() {
    return validationError;
  }

  public void setValidationError(List<String> validationError) {
    this.validationError = validationError;
  }

  public String getErrorMessage() {
    return errorMessage;
  }

  public HttpStatus getStatusCode() {
    return statusCode;
  }

  public CommonException(String errorMessage, HttpStatus statusCode) {
    super();
    this.validationError = null;
    this.errorMessage = errorMessage;
    this.statusCode = statusCode;
  }

  public CommonException(List<String> validationError, HttpStatus statusCode) {
    super();
    this.validationError = validationError;
    this.errorMessage = null;
    this.statusCode = statusCode;
  }
}
