package com.galacticcensus.constant;

public final class MessageConstant {

	public static final String NAME_NOT_BLANK_ERROR_MESSAGE = "{name.not.blank}";
	public static final String NAME_LENGTH_ERROR_MESSAGE = "{name.length}";
	public static final String PLANET_NOT_BLANK_ERROR_MESSAGE = "{planet.not.blank}";
	public static final String PLANET_NAME_LENGTH_ERROR_MESSAGE = "{planet.name.length}";
	public static final String ADDRESS_NOT_BLANK_ERROR_MESSAGE = "{address.not.blank}";
	public static final String ADDRESS_LENGTH_ERROR_MESSAGE = "{address.name.length}";
	public static final String INCOME_NOT_BLANK_ERROR_MESSAGE = "{income.not.null}";
	public static final String INCOME_VALUE_ERROR_MESSAGE = "{income.value}";

	private MessageConstant() {
		super();
	}
}
