package com.galacticcensus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.galacticcensus.model.ApiResponse;
import com.galacticcensus.model.PersonVO;
import com.galacticcensus.service.PersonService;

import jakarta.servlet.http.HttpServletResponse;

/**
 * Controller class that handles endpoints related to galactic census data.
 */
@RestController
public class GalacticCensusController {

	@Autowired
	private PersonService personService;

	/**
	 * Person Data Entry Several persons may be entered into the system. Each person
	 * has a full name, date of birth, planet of residence, gender, local address
	 * (on that planet), and annual income. Being able to enter this data is
	 * critical to the Census. Endpoint to create or add a new person.
	 *
	 * @param personVO The PersonVO object containing the details of the person to
	 *                 be added.
	 * @param response The HttpServletResponse object.
	 * @return ResponseEntity containing the ApiResponse with the result of the add
	 *         operation.
	 */

	@PostMapping("/addPerson")
	public ResponseEntity<ApiResponse> addPerson(@Validated @RequestBody final PersonVO personVO,
			final HttpServletResponse response) {
		ApiResponse apiResponse = personService.addPerson(personVO);
		return ResponseEntity.status(HttpStatus.OK).body(apiResponse);
	}

	/**
	 * Person Data Report All the person data in the system may be retrieved at
	 * once. The data should be grouped by planet and gender, and ordered
	 * alphabetically by full name within each planet for each gender. This report
	 * will be needed in the future, but is less immediately valuable than the
	 * various statistics. Endpoint to retrieve the galactic report containing
	 * person data.
	 *
	 * @return ResponseEntity containing the ApiResponse with the galactic report
	 *         data.
	 */
	@GetMapping("/galacticReport")
	public ResponseEntity<ApiResponse> getPersonDataReport() {
		ApiResponse apiResponse = personService.getPersonDataReport();
		return ResponseEntity.status(HttpStatus.OK).body(apiResponse);
	}

	/**
	 * Statistic: Galactic Total : The total number of persons in the Galaxy may be
	 * retrieved from the system. This statistic is one of the primary goals of the
	 * Census. Endpoint to retrieve the total number of persons in the galaxy.
	 *
	 * @return ResponseEntity containing the ApiResponse with the total number of
	 *         persons in the galaxy.
	 */
	@GetMapping("/statistics/galacticTotal")
	public ResponseEntity<ApiResponse> getPersonsCount() {
		ApiResponse apiResponse = personService.getPersonsCount();
		return ResponseEntity.status(HttpStatus.OK).body(apiResponse);
	}

	/**
	 * Statistic: Planetary Total : The total number of persons on any given planet
	 * may be retrieved from the system. This statistic is one of the primary goals
	 * of the Census. Endpoint to retrieve the total number of persons on a specific
	 * planet.
	 *
	 * @param planet The name of the planet for which the total number of persons is
	 *               to be retrieved.
	 * @return ResponseEntity containing the ApiResponse with the total number of
	 *         persons on the specified planet.
	 */
	@GetMapping("/statistics/planetaryTotal/{planet}")
	public ResponseEntity<ApiResponse> getPlanetaryTotal(@PathVariable final String planet) {
		ApiResponse apiResponse = personService.getPlanetaryTotal(planet);
		return ResponseEntity.status(HttpStatus.OK).body(apiResponse);
	}

	/**
	 * Statistic: Planetary Total for any Year in Last 12 years : The total number
	 * of persons on any given planet in any year over the last 12 years may be
	 * retrieved from the system. This statistic is one of the primary goals of the
	 * Census and allows for analysis of the growth or change in population over
	 * time. Endpoint to retrieve the total number of persons on a specific planet
	 * for a given year.
	 *
	 * @param planet The name of the planet for which the total number of persons is
	 *               to be retrieved.
	 * @param year   The year for which the total number of persons is to be
	 *               retrieved.
	 * @return ResponseEntity containing the ApiResponse with the total number of
	 *         persons on the specified planet for the given year.
	 */

	@GetMapping("/statistics/planetaryTotal/{planet}/year/{year}")
	public ResponseEntity<ApiResponse> getPlanetaryTotalByYear(@PathVariable final String planet,
			@PathVariable final String year) {
		ApiResponse apiResponse = personService.getPlanetaryTotalByYear(planet, year);
		return ResponseEntity.status(HttpStatus.OK).body(apiResponse);
	}

	/**
	 * Statistic: Galactic Per Capita Income : The average income per person in the
	 * Galaxy for a given year may be retrieved from the system. This statistic is
	 * required by Government economists. Endpoint to retrieve the galactic per
	 * capita income for a given year.
	 * 
	 * @param year The year for which the galactic per capita income is to be
	 *             retrieved.
	 * @return ResponseEntity containing the ApiResponse with the galactic per
	 *         capita income for the given year.
	 */
	@GetMapping("/statistics/galacticPerCapitaIncome/{year}")
	public ResponseEntity<ApiResponse> getPlanetaryTotalByYear(@PathVariable final String year) {
		ApiResponse apiResponse = personService.getGalacticPerCapitaIncomGByYear(year);
		return ResponseEntity.status(HttpStatus.OK).body(apiResponse);
	}

	/**
	 * Statistic: Planetary Per Capita Income Standard Deviation : The standard
	 * deviation of the average income per person in the Planet for a given year may
	 * be retrieved from the system. This statistic is required by Government
	 * economists. Endpoint to retrieve the standard deviation of the planetary per
	 * capita income for a given year.
	 *
	 *
	 * @param year The year for which the standard deviation of the planetary per
	 *             capita income is to be retrieved.
	 * @return ResponseEntity containing the ApiResponse with the standard deviation
	 *         of the planetary per capita income for the given year.
	 */
	@GetMapping("/statistics/PlanetaryPerCapitaIncomeSD/{year}")
	public ResponseEntity<ApiResponse> getPlanetaryPerCapitaIncomeStandardDeviation(@PathVariable final String year) {
		ApiResponse apiResponse = personService.getPlanetaryPerCapitaIncomeStandardDeviation(year);
		return ResponseEntity.status(HttpStatus.OK).body(apiResponse);
	}

	/**
	 * Statistic: Planetary Per Capita Income : The average income per person on any
	 * given planet for a given year may be retrieved from the system. Some
	 * university researchers have asked for this statistic. Endpoint to retrieve
	 * the per capita income on a specific planet for a given year.
	 *
	 * @param planet The name of the planet for which the per capita income is to be
	 *               retrieved.
	 * @param year   The year for which the per capita income is to be retrieved.
	 * @return ResponseEntity containing the ApiResponse with the per capita income
	 *         on the specified planet for the given year.
	 */
	@GetMapping("/statistics/planetaryPerCaptiaIncome/{planet}/year/{year}")
	public ResponseEntity<ApiResponse> getPlanetaryPerCapitaIncomeByPlanetAndYear(@PathVariable final String planet,
			@PathVariable final String year) {
		ApiResponse apiResponse = personService.getPlanetaryPerCapitaIncomeByPlanetAndYear(planet, year);
		return ResponseEntity.status(HttpStatus.OK).body(apiResponse);
	}

}
