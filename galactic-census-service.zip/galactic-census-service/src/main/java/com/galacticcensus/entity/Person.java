package com.galacticcensus.entity;

import java.io.Serializable;
import java.util.Date;

import com.galacticcensus.enums.GenderEnum;

/**
 * Although there is no database involved, this class is treated as an entity.
 * Represents a person entity with attributes like full name, date of birth,
 * planet of residence, gender, local address, and annual income.
 */
public class Person implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer id;
	private String fullName;
	private Date dateOfBirth;
	private String planetOfResidence;
	private GenderEnum gender;
	private String localAddress;
	private double annualIncome;

	public Person() {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPlanetOfResidence() {
		return planetOfResidence;
	}

	public void setPlanetOfResidence(String planetOfResidence) {
		this.planetOfResidence = planetOfResidence;
	}

	public GenderEnum getGender() {
		return gender;
	}

	public void setGender(GenderEnum gender) {
		this.gender = gender;
	}

	public String getLocalAddress() {
		return localAddress;
	}

	public void setLocalAddress(String localAddress) {
		this.localAddress = localAddress;
	}

	public double getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(double annualIncome) {
		this.annualIncome = annualIncome;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", fullName=" + fullName + ", dateOfBirth=" + dateOfBirth + ", planetOfResidence="
				+ planetOfResidence + ", gender=" + gender + ", localAddress=" + localAddress + ", annualIncome="
				+ annualIncome + "]";
	}

	public Person(Integer id, String fullName, Date dateOfBirth, String planetOfResidence, GenderEnum gender,
			String localAddress, double annualIncome) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.planetOfResidence = planetOfResidence;
		this.gender = gender;
		this.localAddress = localAddress;
		this.annualIncome = annualIncome;
	}

}
