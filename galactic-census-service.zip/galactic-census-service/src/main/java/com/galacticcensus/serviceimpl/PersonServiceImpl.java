package com.galacticcensus.serviceimpl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.galacticcensus.entity.Person;
import com.galacticcensus.enums.GenderEnum;
import com.galacticcensus.exception.CommonException;
import com.galacticcensus.model.ApiResponse;
import com.galacticcensus.model.PersonVO;
import com.galacticcensus.service.PersonService;
import com.galacticcensus.util.DateUtil;
/**
 * Implementation class for the PersonService interface.
 * This class provides concrete implementations of methods to interact with census person data.
 */
@Service
public class PersonServiceImpl implements PersonService {

	@Autowired
	private MessageSource messageSource;

	private final List<Person> censusData = new ArrayList<>();

	private static final String PERSON = "person";

	@Override
	public ApiResponse addPerson(final PersonVO personVO) {
		final ApiResponse apiResponse = new ApiResponse();
		try {

			final Person person = new Person();
			Integer idCount = 1;
			if (CollectionUtils.isNotEmpty(censusData)) {
				idCount = censusData.size() + 1;
			}
			person.setId(idCount);
			person.setFullName(personVO.getFullName());

			final Date dateOfBirth = DateUtil.convertStringToDate(personVO.getDateOfBirth(),
					DateUtil.DATETIME_PATTERN_FOR_LOCALDATE);

			person.setDateOfBirth(dateOfBirth);

			person.setPlanetOfResidence(personVO.getPlanetOfResidence());
			person.setGender(GenderEnum.valueOf(personVO.getGender().toUpperCase()));
			person.setLocalAddress(personVO.getLocalAddress());
			person.setAnnualIncome(Double.parseDouble(personVO.getAnnualIncome()));
			censusData.add(person);

			final String message = messageSource.getMessage("person.creation.msg", new Object[] { idCount },
					LocaleContextHolder.getLocale());

			apiResponse.setMessage(message);
		} catch (Exception e) {
			apiResponse.setErrorMessage("Failed to add person");
		}
		return apiResponse;
	}

	@Override
	public ApiResponse getPersonDataReport() {
		final ApiResponse apiResponse = new ApiResponse();

		if (CollectionUtils.isNotEmpty(censusData)) {
			// Group by planet and gender
			final Map<String, Map<String, List<PersonVO>>> groupedData = censusData.stream().map(person -> {
				PersonVO personVo = preparePersonVo(person);
				return personVo;
			}).collect(
					Collectors.groupingBy(PersonVO::getPlanetOfResidence, Collectors.groupingBy(PersonVO::getGender)));

			// Sort within each group by full name
			groupedData.forEach((planet, genderMap) -> genderMap
					.forEach((gender, personList) -> personList.sort(Comparator.comparing(PersonVO::getFullName))));

			final List<PersonVO> sortedCensusDataVO = groupedData.values().stream().flatMap(m -> m.values().stream())
					.flatMap(List::stream).collect(Collectors.toList());

			apiResponse.setRecords(sortedCensusDataVO);
		} else {
			final String errorMessage = messageSource.getMessage("no.data.found", new Object[] { PERSON },
					LocaleContextHolder.getLocale());
			apiResponse.setMessage(errorMessage);
		}

		return apiResponse;
	}

	@Override
	public ApiResponse getPersonsCount() {
		final ApiResponse apiResponse = new ApiResponse();

		if (CollectionUtils.isNotEmpty(censusData)) {

			final List<PersonVO> censusDataVO = censusData.stream().map(person -> {
				return preparePersonVo(person);
			}).collect(Collectors.toList());

			apiResponse.setRecords(censusDataVO);
			final int personCount = censusData.size();
			apiResponse.setData(personCount);
		} else {
			SetNoDataErrorMessage(apiResponse, PERSON);
		}
		return apiResponse;
	}

	/**
	 * Sets an error message in the ApiResponse indicating data for a specific
	 * argument is not found.
	 *
	 * @param apiResponse The ApiResponse to which the error message will be set.
	 * @param argument    The argument for which the data is not found.
	 */
	private void SetNoDataErrorMessage(final ApiResponse apiResponse, final String argument) {
		final String errorMessage = messageSource.getMessage("argumented.data.not.found", new Object[] { argument },
				LocaleContextHolder.getLocale());
		apiResponse.setMessage(errorMessage);
	}

	/**
	 * Prepares and returns a PersonVO object based on the given Person entity.
	 *
	 * @param person The Person entity containing the person's details.
	 * @return A PersonVO object populated with the person's details.
	 */
	private PersonVO preparePersonVo(final Person person) {
		PersonVO personVo = new PersonVO();
		personVo.setFullName(person.getFullName());

		String dateOfBirth = DateUtil.convertDateToString(person.getDateOfBirth(),
				DateUtil.DATETIME_PATTERN_FOR_LOCALDATE);
		personVo.setDateOfBirth(dateOfBirth);

		personVo.setPlanetOfResidence(person.getPlanetOfResidence());
		personVo.setGender(person.getGender().getValue());
		personVo.setLocalAddress(person.getLocalAddress());
		personVo.setAnnualIncome(String.valueOf(person.getAnnualIncome()));
		return personVo;
	}

	@Override
	public ApiResponse getPlanetaryTotal(final String planet) {
		final List<String> validationErrorr = new ArrayList<String>();
		isPlanetExist(planet, validationErrorr);
		initiateCommonException(validationErrorr);
		final ApiResponse apiResponse = new ApiResponse();
		final List<PersonVO> personVOList = new ArrayList<PersonVO>();
		if (CollectionUtils.isNotEmpty(censusData)) {
			personVOList
					.addAll(censusData.stream().filter(person -> planet.equalsIgnoreCase(person.getPlanetOfResidence()))
							.map(this::preparePersonVo).collect(Collectors.toList()));
			if (CollectionUtils.isNotEmpty(personVOList)) {
				apiResponse.setData(personVOList.size());
				apiResponse.setRecords(personVOList);
			} else {
				SetNoDataErrorMessage(apiResponse, "Planetary total");
			}

		} else {
			SetNoDataErrorMessage(apiResponse, PERSON);
		}
		return apiResponse;
	}

	@Override
	public ApiResponse getPlanetaryTotalByYear(final String planet, final String year) {
		final List<String> validationErrorr = new ArrayList<String>();
		validateYearAndPlanet(planet, year, validationErrorr);
		validateYearWithinSpec(year, validationErrorr);
		initiateCommonException(validationErrorr);
		final ApiResponse apiResponse = new ApiResponse();
		if (CollectionUtils.isNotEmpty(censusData)) {
			List<PersonVO> planteryPAList = censusData.stream()
					.filter(person -> person.getPlanetOfResidence().equalsIgnoreCase(planet))
					.filter(person -> year.equalsIgnoreCase(DateUtil.getYearStringFromDate(person.getDateOfBirth())))
					.map(this::preparePersonVo).collect(Collectors.toList());

			if (CollectionUtils.isNotEmpty(planteryPAList)) {
				apiResponse.setData(planteryPAList.size());
				apiResponse.setRecords(planteryPAList);
			} else {
				SetNoDataErrorMessage(apiResponse, "Per capita income for planet");
			}
		} else {
			SetNoDataErrorMessage(apiResponse, PERSON);
		}

		return apiResponse;
	}

	/**
	 * Throws a CommonException if the validation errors list is not empty.
	 *
	 * @param validationErrorr The list containing validation error messages. If
	 *                         empty, no exception is thrown.
	 */
	private void initiateCommonException(final List<String> validationErrorr) {
		if (CollectionUtils.isNotEmpty(validationErrorr)) {
			throw new CommonException(validationErrorr, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * Validates the provided planet and year, throwing a CommonException if any
	 * validation fails.
	 *
	 * @param planet           The name of the planet to validate.
	 * @param year             The year to validate.
	 * @param validationErrorr The list to which validation error messages will be
	 *                         added.
	 */
	private void validateYearAndPlanet(final String planet, final String year, final List<String> validationErrorr) {
		isPlanetExist(planet, validationErrorr);
		validateYear(year, validationErrorr);
		initiateCommonException(validationErrorr);
	}

	/**
	 * Validates that the provided year falls within a specific range.
	 *
	 * @param year             The year to validate.
	 * @param validationErrorr The list to which validation error messages will be
	 *                         added if validation fails.
	 */
	private void validateYearWithinSpec(final String year, final List<String> validationErrorr) {
		final Integer intYear = Integer.parseInt(year);
		final LocalDate currentDate = LocalDate.now();
		int currentYear = currentDate.getYear();
		if (intYear >= currentYear || intYear < currentYear - 12) {
			final String errorMesaage = messageSource.getMessage("input.year.invalid",
					new Object[] { (currentYear - 12) }, LocaleContextHolder.getLocale());
			validationErrorr.add(errorMesaage);
		}
	}

	/**
	 * Validates the format of the provided year.
	 *
	 * @param year             The year to validate.
	 * @param validationErrorr The list to which validation error messages will be
	 *                         added if validation fails.
	 */
	private void validateYear(final String year, final List<String> validationErrorr) {
		if (!Pattern.matches("^[0-9]{4}$", year)) {
			final String errorMessage = messageSource.getMessage("invalid.argumented.error", new Object[] { "Year" },
					LocaleContextHolder.getLocale());
			validationErrorr.add(errorMessage);
		}
	}

	/**
	 * Checks if the provided planet exists in the census data.
	 *
	 * @param planet           The name of the planet to check.
	 * @param validationErrorr The list to which validation error messages will be
	 *                         added if the planet does not exist.
	 */
	private void isPlanetExist(final String planet, final List<String> validationErrorr) {
		boolean planetExists = censusData.stream()
				.anyMatch(person -> person.getPlanetOfResidence().equalsIgnoreCase(planet));
		if (!planetExists) {
			final String errorMesaage = messageSource.getMessage("planet.invalid", new Object[] { planet },
					LocaleContextHolder.getLocale());
			validationErrorr.add(errorMesaage);
		}

	}

	@Override
	public ApiResponse getGalacticPerCapitaIncomGByYear(final String year) {
		final List<String> validationErrorr = new ArrayList<String>();
		validateYear(year, validationErrorr);
		final ApiResponse apiResponse = new ApiResponse();

		initiateCommonException(validationErrorr);
		if (CollectionUtils.isNotEmpty(censusData)) {
			final double avgIncome = censusData.stream()
					.filter(person -> year.equalsIgnoreCase(DateUtil.getYearStringFromDate(person.getDateOfBirth())))
					.mapToDouble(Person::getAnnualIncome).average().orElse(0.0);
			apiResponse.setData(avgIncome);
		} else {
			SetNoDataErrorMessage(apiResponse, PERSON);
		}
		return apiResponse;
	}

	@Override
	public ApiResponse getPlanetaryPerCapitaIncomeStandardDeviation(final String year) {
		final List<String> validationErrorr = new ArrayList<String>();
		validateYear(year, validationErrorr);
		initiateCommonException(validationErrorr);
		final ApiResponse apiResponse = new ApiResponse();

		if (CollectionUtils.isNotEmpty(censusData)) {

			final Map<String, List<Double>> incomesByPlanet = censusData.stream()
					.filter(person -> year.equalsIgnoreCase(DateUtil.getYearStringFromDate(person.getDateOfBirth())))
					.collect(Collectors.groupingBy(Person::getPlanetOfResidence,
							Collectors.mapping(Person::getAnnualIncome, Collectors.toList())));

			final Map<String, Double> standardDeviationMap = incomesByPlanet.entrySet().stream().collect(
					Collectors.toMap(Map.Entry::getKey, entry -> calculateStandardDeviation(entry.getValue())));

			if (!standardDeviationMap.isEmpty()) {
				apiResponse.setData(standardDeviationMap);
			} else {
				SetNoDataErrorMessage(apiResponse, "Planetary per capita income standardDeviation");
			}

		} else {
			SetNoDataErrorMessage(apiResponse, PERSON);
		}
		return apiResponse;
	}

	/**
	 * Calculates the standard deviation for a list of annual income.
	 *
	 * @param incolmeList The list of values for which the standard deviation is to
	 *                    be calculated.
	 * @return The standard deviation of the provided values. If the calculated
	 *         standard deviation is less than or equal to 0, 0 is returned.
	 */
	private Double calculateStandardDeviation(final List<Double> incolmeList) {
		final DoubleSummaryStatistics stats = new DoubleSummaryStatistics();
		incolmeList.forEach(stats::accept);
		final double average = stats.getAverage();
		final double sumOfSquares = incolmeList.stream().mapToDouble(value -> Math.pow(value - average, 2)).sum();
		final double standardDeviation = Math.sqrt(sumOfSquares / (incolmeList.size() - 1));
		return standardDeviation > 0 ? standardDeviation : 0;
	}

	@Override
	public ApiResponse getPlanetaryPerCapitaIncomeByPlanetAndYear(final String planet, final String year) {
		final List<String> validationErrorr = new ArrayList<String>();
		validateYearAndPlanet(planet, year, validationErrorr);
		final ApiResponse apiResponse = new ApiResponse();

		if (CollectionUtils.isNotEmpty(censusData)) {

			Double averageIncome = findAverageIncomeByPlanetAndYear(planet, year);

			if (averageIncome != null) {
				apiResponse.setData(averageIncome);
			} else {
				SetNoDataErrorMessage(apiResponse, "Average income");
			}

		} else {
			SetNoDataErrorMessage(apiResponse, PERSON);
		}
		return apiResponse;
	}

	/**
	 * Find the average income per person for a given planet and year.
	 *
	 * @param planet Planet name
	 * @param year   Year
	 * @return Optional containing the average income per person, or empty if not
	 *         found
	 */
	private Double findAverageIncomeByPlanetAndYear(final String planet, final String year) {
		return censusData.stream()
				.filter(entry -> entry.getPlanetOfResidence().equalsIgnoreCase(planet)
						&& year.equalsIgnoreCase(DateUtil.getYearStringFromDate(entry.getDateOfBirth())))
				.mapToDouble(Person::getAnnualIncome).average().getAsDouble();

	}

}
