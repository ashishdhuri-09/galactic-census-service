package com.galacticcensus.model;

import java.io.Serializable;

import com.galacticcensus.constant.MessageConstant;
import com.galacticcensus.validations.DateOfBirth;
import com.galacticcensus.validations.Gender;
import com.galacticcensus.validations.IsNumeric;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

/**
 * Use send data to frontend Represents a personVO with attributes like full
 * name, date of birth, planet of residence, gender, local address, and annual
 * income.
 */
public class PersonVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@NotEmpty(message = MessageConstant.NAME_NOT_BLANK_ERROR_MESSAGE)
	@Size(min = 3, max = 500, message = MessageConstant.NAME_LENGTH_ERROR_MESSAGE)
	private String fullName;

	@DateOfBirth
	private String dateOfBirth;

	@NotEmpty(message = MessageConstant.PLANET_NOT_BLANK_ERROR_MESSAGE)
	@Size(max = 500, message = MessageConstant.PLANET_NAME_LENGTH_ERROR_MESSAGE)
	private String planetOfResidence;

	@Gender
	private String gender;

	@NotEmpty(message = MessageConstant.ADDRESS_NOT_BLANK_ERROR_MESSAGE)
	@Size(max = 5000, message = MessageConstant.ADDRESS_LENGTH_ERROR_MESSAGE)
	private String localAddress;

	@IsNumeric
	private String annualIncome;

	public PersonVO() {
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPlanetOfResidence() {
		return planetOfResidence;
	}

	public void setPlanetOfResidence(String planetOfResidence) {
		this.planetOfResidence = planetOfResidence;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLocalAddress() {
		return localAddress;
	}

	public String getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}

	public void setLocalAddress(String localAddress) {
		this.localAddress = localAddress;
	}

	@Override
	public String toString() {
		return "PersonVO [fullName=" + fullName + ", dateOfBirth=" + dateOfBirth + ", planetOfResidence="
				+ planetOfResidence + ", gender=" + gender + ", localAddress=" + localAddress + ", annualIncome="
				+ annualIncome + "]";
	}

	public PersonVO(
			@NotEmpty(message = "{name.not.blank}") @Size(min = 3, max = 500, message = "{name.length}") String fullName,
			String dateOfBirth,
			@NotEmpty(message = "{planet.not.blank}") @Size(max = 500, message = "{planet.name.length}") String planetOfResidence,
			String gender,
			@NotEmpty(message = "{address.not.blank}") @Size(max = 5000, message = "{address.name.length}") String localAddress,
			String annualIncome) {
		super();
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.planetOfResidence = planetOfResidence;
		this.gender = gender;
		this.localAddress = localAddress;
		this.annualIncome = annualIncome;
	}

}
