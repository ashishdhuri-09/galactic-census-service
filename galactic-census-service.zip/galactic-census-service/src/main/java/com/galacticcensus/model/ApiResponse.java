package com.galacticcensus.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This class stores information related to response of the request which
 * contains errorMessage ,message , list of validationError.
 */
@JsonInclude(Include.NON_EMPTY)
public class ApiResponse {

	private List<PersonVO> records = new ArrayList<>();

	private Object data;

	private String message;

	@JsonProperty("error_message")
	private String errorMessage;

	@JsonProperty("field_error")
	private Map<String, Object> fieldError;

	public List<PersonVO> getRecords() {
		return records;
	}

	public void setRecords(List<PersonVO> records) {
		this.records = records;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Map<String, Object> getFieldError() {
		return fieldError;
	}

	public void setFieldError(Map<String, Object> fieldError) {
		this.fieldError = fieldError;
	}

}
