package com.galacticcensus.service;

import com.galacticcensus.model.ApiResponse;
import com.galacticcensus.model.PersonVO;

/**
 * Interface defining operations related to persons.
 * Implementations of this interface provide methods to interact with census person data.
 */
public interface PersonService {

	/**
	 * Adds a new person to the census data based on the provided PersonVO.
	 *
	 * @param personVO The PersonVO containing the details of the person to be added.
	 * @return An ApiResponse indicating the result of the operation.
	 *         If successful, the message will contain a success message with the new person's ID.
	 *         If unsuccessful, the errorMessage will contain details about the failure.
	 */
	ApiResponse addPerson(final PersonVO personVO);

	/**
	 * Retrieves and prepares a report of person data grouped by planet and gender. and 
	 * ordered alphabetically by full name 
	 *
	 * @return An ApiResponse containing the sorted and grouped person data.
	 *         If census data is empty, the ApiResponse message will indicate no data found.
	 */
	ApiResponse getPersonDataReport();

	/**
	 * Retrieves the total count of persons in the census data along with their details.
	 *
	 * @return An ApiResponse containing the total count of persons and their details.
	 *         If census data is empty, an error message will be set in the ApiResponse.
	 */
	ApiResponse getPersonsCount();

	/**
	 * Retrieves the total number of people and their details residing on a specific planet.
	 *
	 * @param planet The name of the planet to filter the data.
	 * @return An ApiResponse containing the total number of people and their details for the specified planet.
	 *         If no data is found for the planet, an error message will be set in the ApiResponse.
	 */
	ApiResponse getPlanetaryTotal(final String planet);

	/**
	 * Retrieves the total count of persons residing on a specific planet for a given year,
	 * along with their details.
	 *
	 * @param planet The name of the planet to filter the data.
	 * @param year   The year to filter the data.
	 * @return An ApiResponse containing the total count of persons and their details for the specified planet and year.
	 *         If no data is found for the specified planet and year, an error message will be set in the ApiResponse.
	 */
	ApiResponse getPlanetaryTotalByYear(final String planet, final String year);

	/**
	 * Retrieves the average annual income per person across all planets for a given year.
	 *
	 * @param year The year to filter the data.
	 * @return An ApiResponse containing the average annual income per person for the specified year.
	 *         If no data is found for the specified year, an error message will be set in the ApiResponse.
	 */

	ApiResponse getGalacticPerCapitaIncomGByYear(final String year);

	/**
	 * Retrieves the standard deviation of per capita income for each planet for a given year.
	 *
	 * @param year The year to filter the data.
	 * @return An ApiResponse containing the standard deviation of per capita income for each planet
	 *         for the specified year.
	 *         If no data is found for the specified year, an error message will be set in the ApiResponse.
	 */
	ApiResponse getPlanetaryPerCapitaIncomeStandardDeviation(final String year);

	/**
	 * Retrieves the average per capita income for a specific planet and year.
	 *
	 * @param planet The name of the planet to filter the data.
	 * @param year   The year to filter the data.
	 * @return An ApiResponse containing the average per capita income for the specified planet and year.
	 *         If no data is found for the specified planet and year, an error message will be set in the ApiResponse.
	 */
	ApiResponse getPlanetaryPerCapitaIncomeByPlanetAndYear(final String planet, final String year);

}
