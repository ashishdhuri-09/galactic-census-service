package com.galacticcensus.util;

import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Utility class for date-related operations.
 * This class provides methods for various date manipulations and calculations.
 */
@Component
public final class DateUtil {

	private static final Logger LOG = LoggerFactory.getLogger(DateUtil.class);

	public static final String DATETIME_PATTERN_FOR_LOCALDATE = "dd/MM/yyyy";

	private DateUtil() {
	}

	/**
	 * Converts a Date object to a String representation using the specified date
	 * format.
	 *
	 * @param aDate      The Date object to convert.
	 * @param dateFormat The format string to use for the conversion.
	 * @return A String representation of the Date in the specified format, or an
	 *         empty string if the input is null or the format is blank.
	 */
	public static String convertDateToString(final Date aDate, final String dateFormat) {
		if (aDate == null || StringUtils.isBlank(dateFormat)) {
			return "";
		}
		return getDateTime(dateFormat, aDate);
	}

	public static Date convertStringToDate(final String strDate, final String aMask) {
		SimpleDateFormat df = null;
		Date date = null;
		df = new SimpleDateFormat(aMask);
		try {
			if (StringUtils.isNotBlank(strDate)) {
				date = df.parse(strDate);
			}
		} catch (final Exception pe) {
			LOG.error("Date parsing exception expected format: ".concat(aMask).concat(" Date recieved :")
					.concat(strDate));
		}
		return date;
	}

	/**
	 * Converts a string representation of a date to a Date object using the
	 * specified date format.
	 *
	 * @param strDate The string representation of the date to convert.
	 * @param aMask   The format string to use for parsing the date.
	 * @return A Date object representing the parsed date, or null if the input is
	 *         blank or the parsing fails.
	 */
	public static String getDateTime(final String aMask, final Date aDate) {
		SimpleDateFormat df = null;
		String returnValue = "";

		if (aDate == null) {
			LOG.debug("aDate is null!");
		} else {
			df = new SimpleDateFormat(aMask);
			returnValue = df.format(aDate);
		}

		return returnValue;
	}

	/**
	 * Converts java.util.Date to java.time.LocalDate
	 *
	 * @param date java.util.Date to be converted
	 * @return java.time.LocalDate converted from java.util.Date
	 */
	public static String getYearStringFromDate(final Date date) {
		final Integer year = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().getYear();
		return String.valueOf(year != null ? year : null);
	}

}