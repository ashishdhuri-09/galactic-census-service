package com.galacticcensus.config;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;

/**
 * This is configuration related class. In this class application related
 * configuration done
 */
@Configuration
public class Config implements WebMvcConfigurer {

	/**
	 * Creates a MessageSource bean for internationalization and localization
	 * purposes.
	 *
	 * @return the created MessageSource bean
	 */
	@Bean
	MessageSource messageSource() {
		ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
		messageSource.setBasename("messages"); // sets the basename of the message resource bundle
		messageSource.setDefaultEncoding("UTF-8"); // sets the default encoding for message properties files
		return messageSource; // returns the created message source.
	}

	/**
	 * Creates a LocalValidatorFactoryBean bean for validating objects and their
	 * fields. The validation messages are retrieved from the message source bean.
	 *
	 * @return the created LocalValidatorFactoryBean bean
	 */
	@Override
	@Bean
	public LocalValidatorFactoryBean getValidator() {
		LocalValidatorFactoryBean bean = new LocalValidatorFactoryBean();
		// sets the message source for the validator to retrieve validation messages
		bean.setValidationMessageSource(messageSource());
		return bean; // returns the created validator bean
	}

	/**
	 * Creates a AcceptHeaderLocaleResolver bean for resolving the locale of the
	 * user based on the Accept-Language header of the HTTP request. The default
	 * locale is set to English.
	 *
	 * @return the created AcceptHeaderLocaleResolver bean.
	 */
	@Bean
	AcceptHeaderLocaleResolver customeLocaleResolver() {
		AcceptHeaderLocaleResolver slr = new AcceptHeaderLocaleResolver();
		slr.setDefaultLocale(Locale.ENGLISH); // sets the default locale to English
		return slr; // returns the created locale resolver bean.
	}

}
