package com.galacticcensus.exceptionhandler;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.galacticcensus.exception.CommonException;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;

/**
 * GalacticCensusExceptionControllerAdvice is a Spring REST Controller Advice
 * class that handles exceptions in a application. It provides exception
 * handling methods for various types of exceptions and returns appropriate
 * ResponseEntity objects with error responses.
 */
@RestControllerAdvice
public class GalacticCensusExceptionControllerAdvice {
	private static final Logger LOGGER = LoggerFactory.getLogger(GalacticCensusExceptionControllerAdvice.class);

	public static final String ERROR_MESSAGE = "error_message";

	public static final String PAYLOAD_RESPONSE = "payloadResponse";

	public static final String STATUS_CODE = "statusCode";

	public static final String ERROR_VIEW_PAGE = "error";

	public static final String GENERIC_ERROR_MESSAGE = "Something went wrong";

	/**
	 * Handles generic exceptions of type Exception. Logs the error message and
	 * returns an error response with internal server error status.
	 *
	 * @param exception The Exception object that occurred
	 * @return ResponseEntity with error response and internal server error status
	 */
	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<Object> handleException(Exception exception) {
		LOGGER.error("Exception - ", exception);
		HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
		Map<String, Object> errorResponse = new HashMap<>();
		errorResponse.put(ERROR_MESSAGE, GENERIC_ERROR_MESSAGE);
		return ResponseEntity.status(status).body(errorResponse);
	}

	/**
	 * Global exception handler for handling MethodArgumentNotValidException in a
	 * Spring application.
	 *
	 * <p>
	 * This method is annotated with {@code @ExceptionHandler}, indicating that it
	 * will handle exceptions of type {@code MethodArgumentNotValidException} thrown
	 * by the controller methods. This exception is usually thrown when there are
	 * validation errors in the request payload, typically when using Spring's
	 * validation annotations like {@code @Valid}.
	 *
	 * @param ex The {@code MethodArgumentNotValidException} that is caught and
	 *           handled by this method.
	 * @return A {@code PayloadResponse} object containing the validation errors as
	 *         a Map of field names and their corresponding error messages.
	 */
	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public ResponseEntity<Object> handleValidationExceptions(MethodArgumentNotValidException ex) {
		Map<String, Object> errors = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(error -> {
			if (errors.containsKey(error.getField())) {
				errors.put(error.getField(),
						String.format("%s, %s", errors.get(error.getField()), error.getDefaultMessage()));
			} else {
				errors.put(error.getField(), error.getDefaultMessage());
			}
		});
		HttpStatus status = HttpStatus.BAD_REQUEST;
		return ResponseEntity.status(status).body(errors);
	}

	/**
	 * Handles exceptions of type MissingServletRequestParameterException. Logs the
	 * warning message, sets error response with error message, and returns an error
	 * response with not found status.
	 *
	 * @param exception The MissingServletRequestParameterException object that
	 *                  occurred
	 * @return ResponseEntity with error response and not found status
	 */
	@ExceptionHandler(value = MissingServletRequestParameterException.class)
	public ResponseEntity<Object> handleMissingServletRequestParameterException(
			MissingServletRequestParameterException exception) {
		LOGGER.error("MissingServletRequestParameterException - ", exception);
		HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
		Map<String, Object> errorResponse = new HashMap<>();
		errorResponse.put(ERROR_MESSAGE, exception.getMessage());
		return ResponseEntity.status(status).body(errorResponse);
	}

	/**
	 * Handles ConstraintViolationException and returns a ResponseEntity with a
	 * PayloadResponse and a HTTP status code of 400 (BAD_REQUEST).
	 *
	 * @param exception The ConstraintViolationException to handle
	 * @return A ResponseEntity containing a PayloadResponse and a HTTP status code
	 *         of 400 (BAD_REQUEST)
	 */
	@ExceptionHandler(value = ConstraintViolationException.class)
	public ResponseEntity<Object> handleConstraintViolationException(ConstraintViolationException exception) {
		// Handle constraint violations
		Map<String, Object> errorResponse = new HashMap<>();
		// Handle constraint violations
		Set<ConstraintViolation<?>> constraintViolations = exception.getConstraintViolations();
		if (constraintViolations != null && !constraintViolations.isEmpty()) {
			for (ConstraintViolation<?> violation : constraintViolations) {
				String fieldName = getFieldNameFromPropertyPath(violation.getPropertyPath().toString());
				String errorMessage = violation.getMessage();
				errorResponse.put(fieldName, errorMessage);
			}
		}
		LOGGER.error("ConstraintViolationException - ", exception);
		HttpStatus status = HttpStatus.BAD_REQUEST;
		return ResponseEntity.status(status).body(errorResponse);
	}

	private String getFieldNameFromPropertyPath(String propertyPath) {
		String[] propertyPathElements = propertyPath.split("\\.");
		if (propertyPathElements.length > 0) {
			return propertyPathElements[propertyPathElements.length - 1];
		}
		return propertyPath;
	}

	/**
	 * Handles IllegalArgumentException and returns a ResponseEntity with a
	 * PayloadResponse and a HTTP status code of 400 (BAD_REQUEST).
	 *
	 * @param exception The IllegalArgumentException to handle
	 * @return A ResponseEntity containing a PayloadResponse and a HTTP status code
	 *         of 400 (BAD_REQUEST)
	 */
	@ExceptionHandler(value = IllegalArgumentException.class)
	public ResponseEntity<Object> handleIllegalArgumentException(IllegalArgumentException exception) {
		LOGGER.error("IllegalArgumentException Error - ", exception);
		HttpStatus status = HttpStatus.BAD_REQUEST;
		Map<String, Object> errorResponse = new HashMap<>();
		errorResponse.put(ERROR_MESSAGE, exception.getMessage());
		return ResponseEntity.status(status).body(errorResponse);
	}

	/**
	 * Exception handler for HttpMessageNotReadableException.
	 *
	 * @param exception The HttpMessageNotReadableException to handle.
	 * @return ResponseEntity with a PayloadResponse containing the exception
	 *         message and HttpStatus.BAD_REQUEST.
	 */
	@ExceptionHandler(value = HttpMessageNotReadableException.class)
	public ResponseEntity<Object> handleHttpMessageNotReadableException(HttpMessageNotReadableException exception) {
		LOGGER.error("HttpMessageNotReadableException Error - ", exception);
		HttpStatus status = HttpStatus.BAD_REQUEST;
		Map<String, Object> errorResponse = new HashMap<>();
		errorResponse.put(ERROR_MESSAGE, exception.getMessage());
		return ResponseEntity.status(status).body(errorResponse);
	}

	/**
	 * Exception handler method to handle {@link ResourceNotFoundException}. This
	 * method is triggered when a resource (e.g., a specific entity or object) is
	 * not found in the system. It logs the error using the application logger and
	 * constructs a response entity containing the error message to be sent as a
	 * response to the client.
	 *
	 * @param exception The {@link ResourceNotFoundException} instance that was
	 *                  thrown.
	 * @return A {@link ResponseEntity} containing a map with the error message to
	 *         be returned to the client. The HTTP status of the response is set to
	 *         {@link HttpStatus#BAD_REQUEST} (400).
	 */
	@ExceptionHandler(CommonException.class)
	public ResponseEntity<Object> commonException(CommonException exception) {
		LOGGER.error("ResourceNotFoundException Error - ", exception);
		HttpStatus status = exception.getStatusCode();
		Map<String, Object> errorResponse = new HashMap<>();
		if (CollectionUtils.isNotEmpty(exception.getValidationError())) {
			errorResponse.put(ERROR_MESSAGE, exception.getValidationError());
		}
		if (StringUtils.isNotBlank(exception.getErrorMessage())) {
			String errorMessage = exception.getErrorMessage();
			errorResponse.put(ERROR_MESSAGE, errorMessage);
		}
		return ResponseEntity.status(status).body(errorResponse);
	}

}
