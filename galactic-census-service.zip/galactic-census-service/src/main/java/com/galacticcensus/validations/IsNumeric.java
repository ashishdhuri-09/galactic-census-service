package com.galacticcensus.validations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.validation.Constraint;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;

/**
 * Custom validation annotation for validating numeric values.
 * This annotation validates that the provided value is numeric and matches a specific pattern.
 */
@Documented
@Constraint(validatedBy = { IsNumeric.NumericValueValidator.class })
@Target({ ElementType.FIELD, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
public @interface IsNumeric {

	String message() default "Value must be numeric";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};

	class NumericValueValidator implements ConstraintValidator<IsNumeric, String> {
		private static final String POSITIVE_NUMBER_PATTERN = "^[1-9]\\d*(\\.\\d+)?$";

		@Override
		public boolean isValid(String value, ConstraintValidatorContext context) {
			if (value == null || value.trim().isEmpty()) {
				context.disableDefaultConstraintViolation();
				context.buildConstraintViolationWithTemplate("{income.not.null}").addConstraintViolation();
				return false;
			}
			try {
				Double.parseDouble(value);
			} catch (NumberFormatException e) {
				context.disableDefaultConstraintViolation();
				context.buildConstraintViolationWithTemplate("{income.numeric.value}").addConstraintViolation();
				return false;
			}

			if (!value.matches(POSITIVE_NUMBER_PATTERN)) {
				context.disableDefaultConstraintViolation();
				context.buildConstraintViolationWithTemplate("{income.value}").addConstraintViolation();
				return false;
			}
			return true;

		}
	}
}
