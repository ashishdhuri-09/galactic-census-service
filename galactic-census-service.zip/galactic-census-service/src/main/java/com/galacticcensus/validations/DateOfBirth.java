package com.galacticcensus.validations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.galacticcensus.util.DateUtil;

import jakarta.validation.Constraint;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;
import jakarta.validation.ReportAsSingleViolation;
/**
 * Custom validation annotation for validating date of birth.
 * This annotation validates that the provided date of birth is in the correct format and is a valid date.
 */
@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = { DateOfBirth.DateOfBirthValidator.class })
@ReportAsSingleViolation
public @interface DateOfBirth {

	String message() default "";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};

	class DateOfBirthValidator implements ConstraintValidator<DateOfBirth, String> {
		@Override
		public boolean isValid(String value, ConstraintValidatorContext context) {
			if (value == null || value.trim().isEmpty()) {
				context.disableDefaultConstraintViolation();
				context.buildConstraintViolationWithTemplate("{dateOfBirth.not.empty}").addConstraintViolation();
				return false;
			}

			if (!value.matches("^\\d{2}/\\d{2}/\\d{4}$")) {
				context.disableDefaultConstraintViolation();
				context.buildConstraintViolationWithTemplate("{dateOfBirth.pattern}").addConstraintViolation();
				return false;
			}

			try {
				// Check if the date has extra parts
				String[] parts = value.split("/");
				if (parts.length != 3 || parts[2].length() > 4) {
					context.disableDefaultConstraintViolation();
					context.buildConstraintViolationWithTemplate("{date.invalid}").addConstraintViolation();
					return false;
				}

				// Additional check for valid day, month, and year values
				int day = Integer.parseInt(parts[0]);
				int month = Integer.parseInt(parts[1]);
				int year = Integer.parseInt(parts[2]);

				if (day < 1 || day > 31) {
					context.disableDefaultConstraintViolation();
					context.buildConstraintViolationWithTemplate("{day.value.error}").addConstraintViolation();
					return false;
				}

				if (month < 1 || month > 12) {
					context.disableDefaultConstraintViolation();
					context.buildConstraintViolationWithTemplate("{month.value.error}").addConstraintViolation();
					return false;
				}

				// Check for February and leap years
				if (month == 2) {
					if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) { // Leap year
						if (day > 29) {
							context.disableDefaultConstraintViolation();
							context.buildConstraintViolationWithTemplate("{feb.leap.error}").addConstraintViolation();
							return false;
						}
					} else {
						if (day > 28) {
							context.disableDefaultConstraintViolation();
							context.buildConstraintViolationWithTemplate("{feb.day.error}").addConstraintViolation();
							return false;
						}
					}
				}

				SimpleDateFormat sdf = new SimpleDateFormat(DateUtil.DATETIME_PATTERN_FOR_LOCALDATE);
				sdf.setLenient(false); // This will make sure the date is strict
				// Try to parse the date
				sdf.parse(value);

			} catch (ParseException | NumberFormatException e) {
				context.disableDefaultConstraintViolation();
				context.buildConstraintViolationWithTemplate("{date.invalid}").addConstraintViolation();
				return false;
			}

			return true;
		}
	}

}
