package com.galacticcensus.validations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.galacticcensus.enums.GenderEnum;

import jakarta.validation.Constraint;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;

/**
 * Custom validation annotation for validating gender.
 * This annotation validates that the provided gender value is one of the predefined gender 
 * {@link com.galacticcensus.enums.GenderEnum}
 */
@Documented
@Constraint(validatedBy = { Gender.GenderValidator.class })
@Target({ ElementType.FIELD, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
public @interface Gender {

	String message() default "";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};

	class GenderValidator implements ConstraintValidator<Gender, String> {
		@Override
		public boolean isValid(String value, ConstraintValidatorContext context) {
			if (value == null || value.trim().isEmpty()) {
				context.disableDefaultConstraintViolation();
				context.buildConstraintViolationWithTemplate("{gender.not.empty}").addConstraintViolation();
				return false;
			}

			if (!GenderEnum.contains(value)) {
				context.disableDefaultConstraintViolation();
				context.buildConstraintViolationWithTemplate("{gender.pattern}").addConstraintViolation();
				return false;
			}
			return true;

		}
	}
}
